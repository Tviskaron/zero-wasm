def public_prompt(instructions: str, current_text: dict, history: list[dict], history_size: int = 4) -> str:
    """Use only public observations and executed actions; never teacher thoughts."""
    pieces = [instructions, "\nRecent history:"]
    for turn in history[-history_size:] if history_size else []:
        pieces.append("Observation: " + turn["text"]["long_term_context"])
        pieces.append("Action: " + turn["action"])
    pieces.extend(["\nCurrent observation:", current_text["long_term_context"],
                   current_text["short_term_context"], "\nResponse:\n"])
    return "\n".join(pieces)
